import { NgFor } from '@angular/common';
import { Component, Input } from '@angular/core';
import {NgModule} from '@angular/core';



@Component({
  selector: 'app-investment-results',
  imports: [NgFor],
  templateUrl: './investment-results.component.html',
  styleUrl: './investment-results.component.css'
})
export class InvestmentResultsComponent {

 @Input() results ?: {
      year: number,
      interest: number,
      valueEndOfYear: number,
      annualInvestment: number,
      totalInterest: number,
      totalAmountInvested: number,
    }[];
    
  

}
